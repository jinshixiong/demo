<template>
  <el-container class="layout-container">
    <el-aside width="200px" class="sidebar">
      <div class="logo">评标专家系统</div>
      <el-menu
        :default-active="$route.path"
        router
        background-color="#304156"
        text-color="#fff"
        active-text-color="#409EFF"
      >
        <el-submenu index="/expert">
          <template slot="title">
            <i class="el-icon-user"></i>
            <span>评标专家管理</span>
          </template>
          <el-menu-item index="/expert/type">专业类型</el-menu-item>
          <el-menu-item index="/expert/list">专家列表</el-menu-item>
        </el-submenu>
        <el-menu-item index="/extract">
          <i class="el-icon-s-order"></i>
          <span slot="title">评标专家抽取</span>
        </el-menu-item>
        <el-menu-item index="/record">
          <i class="el-icon-document"></i>
          <span slot="title">抽取记录</span>
        </el-menu-item>
      </el-menu>
    </el-aside>
    <el-container>
      <el-header class="header">
        <span class="header-title">评标专家抽取系统</span>
      </el-header>
      <el-main class="main-content">
        <router-view />
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
export default {
  name: 'Layout'
}
</script>

<style scoped>
.layout-container {
  height: 100vh;
}
.sidebar {
  background-color: #304156;
}
.logo {
  height: 60px;
  line-height: 60px;
  text-align: center;
  color: #fff;
  font-size: 18px;
  font-weight: bold;
  border-bottom: 1px solid #1f2d3d;
}
.header {
  background-color: #fff;
  box-shadow: 0 1px 4px rgba(0,21,41,.08);
  display: flex;
  align-items: center;
}
.header-title {
  font-size: 16px;
  font-weight: bold;
  color: #303133;
}
.main-content {
  background-color: #f0f2f5;
  padding: 20px;
}
</style>