<template>
  <div class="confirm-page">
    <el-card v-if="loading" class="box-card"><div style="text-align: center; padding: 50px;"><i class="el-icon-loading" style="font-size: 30px;"></i><p>加载中...</p></div></el-card>
    <el-card v-else-if="error" class="box-card"><div style="text-align: center; padding: 50px; color: #f56c6c;"><i class="el-icon-error" style="font-size: 50px;"></i><p>{{ error }}</p></div></el-card>
    <el-card v-else class="box-card">
      <div slot="header" style="text-align: center;"><h2>评标确认</h2></div>
      <div style="padding: 20px;">
        <el-descriptions :column="1" border>
          <el-descriptions-item label="项目名称">{{ detail.projectName }}</el-descriptions-item>
          <el-descriptions-item label="项目编号">{{ detail.projectCode }}</el-descriptions-item>
          <el-descriptions-item label="开标时间">{{ detail.openTime }}</el-descriptions-item>
          <el-descriptions-item label="会议类型">{{ detail.meetingType === 'qualification' ? '资格审查会议' : '评会会议' }}</el-descriptions-item>
          <el-descriptions-item label="专家姓名">{{ detail.expertName }}</el-descriptions-item>
        </el-descriptions>
        <div v-if="detail.confirmStatus === 0" style="text-align: center; margin-top: 30px;">
          <p style="margin-bottom: 20px; font-size: 16px;">请确认是否参加本次评标工作？</p>
          <el-button type="success" size="large" @click="handleConfirm(1)">可以参加</el-button>
          <el-button type="danger" size="large" @click="handleConfirm(2)">不方便参加</el-button>
        </div>
        <div v-else style="text-align: center; margin-top: 30px;">
          <el-tag :type="detail.confirmStatus === 1 ? 'success' : 'info'" size="medium" style="font-size: 16px; padding: 10px 20px;">
            {{ detail.confirmStatus === 1 ? '您已确认参加' : '您已拒绝参加' }}
          </el-tag>
          <p style="margin-top: 10px; color: #909399;">确认时间：{{ detail.confirmTime }}</p>
        </div>
      </div>
    </el-card>
  </div>
</template>

<script>
import { getConfirmationDetail, confirmParticipation } from '@/api/confirmation'

export default {
  name: 'Confirm',
  data() { return { loading: true, error: null, detail: {} } },
  created() { this.fetchDetail() },
  methods: {
    async fetchDetail() {
      const token = this.$route.params.token
      if (!token) { this.error = '无效的链接'; this.loading = false; return }
      try {
        const res = await getConfirmationDetail(token)
        this.detail = res.data
      } catch (e) { this.error = e.response?.data?.message || '加载失败' }
      this.loading = false
    },
    async handleConfirm(status) {
      const token = this.$route.params.token
      try {
        await confirmParticipation(token, status)
        this.$message.success(status === 1 ? '确认成功，感谢您的参与！' : '已记录您的回复')
        this.fetchDetail()
      } catch (e) { this.$message.error('操作失败，请重试') }
    }
  }
}
</script>

<style scoped>
.confirm-page { max-width: 800px; margin: 50px auto; }
.box-card { box-shadow: 0 2px 12px 0 rgba(0,0,0,.1); }
</style>