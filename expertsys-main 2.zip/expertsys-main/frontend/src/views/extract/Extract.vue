<template>
  <div class="extract-page">
    <el-card class="box-card">
      <div slot="header"><span>评标专家抽取</span></div>
      <el-form :model="form" :rules="rules" ref="form" label-width="120px">
        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item label="项目名称" prop="projectName">
              <el-input v-model="form.projectName" placeholder="请输入项目名称"/>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="项目编号" prop="projectCode">
              <el-input v-model="form.projectCode" placeholder="请输入项目编号"/>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item label="开标人员" prop="openerName">
              <el-input v-model="form.openerName" placeholder="请输入开标人员姓名"/>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="身份证号" prop="openerIdCard">
              <el-input v-model="form.openerIdCard" placeholder="请输入开标人员身份证号"/>
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item label="开标时间" prop="openTime">
          <el-date-picker v-model="form.openTime" type="datetime" placeholder="选择开标时间" style="width: 100%"/>
        </el-form-item>
        <el-form-item label="可选专业类型" prop="typeIds">
          <el-select v-model="form.typeIds" multiple placeholder="请选择专业类型" style="width: 100%">
            <el-option v-for="type in typeList" :key="type.id" :label="type.name" :value="type.id"/>
          </el-select>
        </el-form-item>
        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item label="资格审查会议" prop="qualificationExpertCount">
              <el-input-number v-model="form.qualificationExpertCount" :min="1" :max="10"/>
              <span style="margin-left: 10px">人</span>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="评会会议" prop="evaluationExpertCount">
              <el-input-number v-model="form.evaluationExpertCount" :min="1" :max="10"/>
              <span style="margin-left: 10px">人</span>
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item>
          <el-button type="primary" @click="handleExtract" :loading="extracting">开始抽取</el-button>
          <el-button @click="resetForm">重置</el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <el-card v-if="extractResult" class="result-card" style="margin-top: 20px;">
      <div slot="header">
        <span>抽取结果</span>
        <el-button v-if="canDownload" style="float: right;" type="success" size="small" @click="downloadAuth">下载授权函</el-button>
      </div>
      <h4>资格审查会议专家</h4>
      <el-table :data="extractResult.qualificationExperts" border>
        <el-table-column type="index" label="序号" width="60"/>
        <el-table-column prop="name" label="姓名"/>
        <el-table-column prop="typeName" label="专业类型"/>
        <el-table-column prop="phone" label="联系电话"/>
        <el-table-column prop="confirmStatus" label="确认状态">
          <template slot-scope="scope">
            <el-tag :type="scope.row.confirmStatus === 1 ? 'success' : scope.row.confirmStatus === 2 ? 'danger' : 'warning'">
              {{ scope.row.confirmStatus === 1 ? '已确认' : scope.row.confirmStatus === 2 ? '已拒绝' : '待确认' }}
            </el-tag>
          </template>
        </el-table-column>
      </el-table>
      <h4 style="margin-top: 20px;">评会会议专家</h4>
      <el-table :data="extractResult.evaluationExperts" border>
        <el-table-column type="index" label="序号" width="60"/>
        <el-table-column prop="name" label="姓名"/>
        <el-table-column prop="typeName" label="专业类型"/>
        <el-table-column prop="phone" label="联系电话"/>
        <el-table-column prop="confirmStatus" label="确认状态">
          <template slot-scope="scope">
            <el-tag :type="scope.row.confirmStatus === 1 ? 'success' : scope.row.confirmStatus === 2 ? 'danger' : 'warning'">
              {{ scope.row.confirmStatus === 1 ? '已确认' : scope.row.confirmStatus === 2 ? '已拒绝' : '待确认' }}
            </el-tag>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script>
import { extractExperts } from '@/api/extract'
import { getTypeList } from '@/api/expertType'

export default {
  name: 'Extract',
  data() {
    return {
      form: {
        projectName: '', projectCode: '', openerName: '', openerIdCard: '',
        openTime: '', typeIds: [], qualificationExpertCount: 1, evaluationExpertCount: 1
      },
      rules: {
        projectName: [{ required: true, message: '请输入项目名称', trigger: 'blur' }],
        projectCode: [{ required: true, message: '请输入项目编号', trigger: 'blur' }],
        openerName: [{ required: true, message: '请输入开标人员姓名', trigger: 'blur' }],
        openerIdCard: [{ required: true, message: '请输入开标人员身份证号', trigger: 'blur' }],
        openTime: [{ required: true, message: '请选择开标时间', trigger: 'change' }],
        typeIds: [{ required: true, message: '请选择可选专业类型', trigger: 'change' }]
      },
      typeList: [], extracting: false, extractResult: null, canDownload: false
    }
  },
  created() { this.fetchTypeList() },
  methods: {
    async fetchTypeList() {
      try { const res = await getTypeList(); this.typeList = res.data || [] } catch(e) {}
    },
    handleExtract() {
      this.$refs.form.validate(async valid => {
        if (valid) {
          this.extracting = true
          try {
            const res = await extractExperts(this.form)
            this.extractResult = res.data
            this.$message.success('抽取成功')
            this.checkCanDownload()
          } catch (error) { this.$message.error(error.response?.data?.message || '抽取失败') }
          this.extracting = false
        }
      })
    },
    checkCanDownload() {
      if (!this.extractResult) return
      const all = [...this.extractResult.qualificationExperts, ...this.extractResult.evaluationExperts]
      this.canDownload = all.every(e => e.confirmStatus === 1)
    },
    downloadAuth() { window.open(`/api/extract-record/${this.extractResult.projectId}/download`, '_blank') },
    resetForm() { this.$refs.form.resetFields(); this.extractResult = null }
  }
}
</script>

<style scoped>.result-card { margin-top: 20px; }</style>