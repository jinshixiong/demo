<template>
  <div class="record-list">
    <el-card class="box-card">
      <div slot="header"><span>抽取记录</span></div>
      <el-table :data="tableData" v-loading="loading" border>
        <el-table-column prop="projectName" label="项目名称"/>
        <el-table-column prop="projectCode" label="项目编号"/>
        <el-table-column prop="extractTime" label="抽取时间" width="180"/>
        <el-table-column label="专家信息">
          <template slot-scope="scope">
            <div v-for="(expert, idx) in scope.row.experts" :key="idx">
              {{ expert.expertName }} - {{ expert.typeName }} ({{ expert.meetingType === 'qualification' ? '资格审查' : '评会' }})
            </div>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="120">
          <template slot-scope="scope">
            <el-button size="mini" type="primary" @click="downloadAuth(scope.row)">下载授权函</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script>
import { getRecordList } from '@/api/extract'

export default {
  name: 'RecordList',
  data() { return { tableData: [], loading: false } },
  created() { this.fetchData() },
  methods: {
    async fetchData() {
      this.loading = true
      try { const res = await getRecordList(); this.tableData = res.data || [] } catch(e) { this.$message.error('获取数据失败') }
      this.loading = false
    },
    downloadAuth(row) { window.open(`/api/extract-record/${row.projectId}/download`, '_blank') }
  }
}
</script>