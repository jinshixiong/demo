<template>
  <div class="type-list">
    <el-card class="box-card">
      <div slot="header" class="clearfix">
        <span>专业类型管理</span>
        <el-button style="float: right; padding: 3px 0" type="text" @click="handleAdd">新增类型</el-button>
      </div>
      <el-table :data="tableData" v-loading="loading" border style="width: 100%">
        <el-table-column prop="name" label="类型名称"></el-table-column>
        <el-table-column prop="sortOrder" label="排序" width="100"></el-table-column>
        <el-table-column label="操作" width="180">
          <template slot-scope="scope">
            <el-button size="mini" @click="handleEdit(scope.row)">编辑</el-button>
            <el-button size="mini" type="danger" @click="handleDelete(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-dialog :title="dialogTitle" :visible.sync="dialogVisible" width="500px">
      <el-form :model="form" :rules="rules" ref="form" label-width="100px">
        <el-form-item label="类型名称" prop="name">
          <el-input v-model="form.name"></el-input>
        </el-form-item>
        <el-form-item label="排序" prop="sortOrder">
          <el-input-number v-model="form.sortOrder" :min="0"></el-input-number>
        </el-form-item>
      </el-form>
      <div slot="footer">
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="submitForm">确定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { getTypeList, addType, updateType, deleteType } from '@/api/expertType'

export default {
  name: 'TypeList',
  data() {
    return {
      tableData: [],
      loading: false,
      dialogVisible: false,
      dialogTitle: '',
      form: { name: '', sortOrder: 0 },
      rules: { name: [{ required: true, message: '请输入类型名称', trigger: 'blur' }] }
    }
  },
  created() {
    this.fetchData()
  },
  methods: {
    async fetchData() {
      this.loading = true
      try {
        const res = await getTypeList()
        this.tableData = res.data || []
      } catch (error) {
        this.$message.error('获取数据失败')
      }
      this.loading = false
    },
    handleAdd() {
      this.dialogTitle = '新增类型'
      this.form = { name: '', sortOrder: 0 }
      this.dialogVisible = true
    },
    handleEdit(row) {
      this.dialogTitle = '编辑类型'
      this.form = { ...row }
      this.dialogVisible = true
    },
    async submitForm() {
      this.$refs.form.validate(async valid => {
        if (valid) {
          try {
            if (this.form.id) {
              await updateType(this.form)
            } else {
              await addType(this.form)
            }
            this.$message.success('保存成功')
            this.dialogVisible = false
            this.fetchData()
          } catch (error) {
            this.$message.error('保存失败')
          }
        }
      })
    },
    async handleDelete(row) {
      this.$confirm('确认删除该类型？', '提示', { type: 'warning' }).then(async () => {
        try {
          await deleteType(row.id)
          this.$message.success('删除成功')
          this.fetchData()
        } catch (error) {
          this.$message.error('删除失败')
        }
      })
    }
  }
}
</script>
