<template>
  <div class="expert-list">
    <el-card class="box-card">
      <div slot="header" class="clearfix">
        <span>评标专家管理</span>
        <el-button style="float: right; padding: 3px 0" type="text" @click="handleAdd">新增专家</el-button>
      </div>
      <el-table :data="tableData" v-loading="loading" border style="width: 100%">
        <el-table-column prop="name" label="姓名"></el-table-column>
        <el-table-column prop="idCardMasked" label="身份证号"></el-table-column>
        <el-table-column prop="phone" label="联系电话"></el-table-column>
        <el-table-column prop="typeNames" label="专业类型">
          <template slot-scope="scope">
            <el-tag v-for="(type, index) in scope.row.typeNames" :key="index" size="small" style="margin-right: 5px">{{type}}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="projectCount" label="参与项目数" width="100"></el-table-column>
        <el-table-column prop="remark" label="备注" show-overflow-tooltip></el-table-column>
        <el-table-column label="操作" width="180">
          <template slot-scope="scope">
            <el-button size="mini" @click="handleEdit(scope.row)">编辑</el-button>
            <el-button size="mini" type="danger" @click="handleDelete(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-dialog :title="dialogTitle" :visible.sync="dialogVisible" width="600px">
      <el-form :model="form" :rules="rules" ref="form" label-width="100px">
        <el-form-item label="姓名" prop="name">
          <el-input v-model="form.name"></el-input>
        </el-form-item>
        <el-form-item label="身份证号" prop="idCard">
          <el-input v-model="form.idCard"></el-input>
        </el-form-item>
        <el-form-item label="联系电话" prop="phone">
          <el-input v-model="form.phone"></el-input>
        </el-form-item>
        <el-form-item label="专业类型" prop="typeIds">
          <el-select v-model="form.typeIds" multiple placeholder="请选择专业类型" style="width: 100%">
            <el-option v-for="type in typeList" :key="type.id" :label="type.name" :value="type.id"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="备注" prop="remark">
          <el-input type="textarea" v-model="form.remark" rows="3"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer">
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="submitForm">确定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { getExpertList, addExpert, updateExpert, deleteExpert } from '@/api/expert'
import { getTypeList } from '@/api/expertType'

export default {
  name: 'ExpertList',
  data() {
    return {
      tableData: [],
      typeList: [],
      loading: false,
      dialogVisible: false,
      dialogTitle: '',
      form: { name: '', idCard: '', phone: '', typeIds: [], remark: '' },
      rules: {
        name: [{ required: true, message: '请输入姓名', trigger: 'blur' }],
        idCard: [{ required: true, message: '请输入身份证号', trigger: 'blur' }],
        phone: [{ required: true, message: '请输入联系电话', trigger: 'blur' }],
        typeIds: [{ required: true, message: '请选择专业类型', trigger: 'change' }]
      }
    }
  },
  created() {
    this.fetchData()
    this.fetchTypeList()
  },
  methods: {
    async fetchData() {
      this.loading = true
      try {
        const res = await getExpertList()
        this.tableData = res.data || []
      } catch (error) {
        this.$message.error('获取数据失败')
      }
      this.loading = false
    },
    async fetchTypeList() {
      try {
        const res = await getTypeList()
        this.typeList = res.data || []
      } catch (error) {
        console.error('获取类型列表失败')
      }
    },
    handleAdd() {
      this.dialogTitle = '新增专家'
      this.form = { name: '', idCard: '', phone: '', typeIds: [], remark: '' }
      this.dialogVisible = true
    },
    handleEdit(row) {
      this.dialogTitle = '编辑专家'
      this.form = { ...row, typeIds: row.typeIds || [] }
      this.dialogVisible = true
    },
    async submitForm() {
      this.$refs.form.validate(async valid => {
        if (valid) {
          try {
            if (this.form.id) {
              await updateExpert(this.form)
            } else {
              await addExpert(this.form)
            }
            this.$message.success('保存成功')
            this.dialogVisible = false
            this.fetchData()
          } catch (error) {
            this.$message.error('保存失败')
          }
        }
      })
    },
    async handleDelete(row) {
      this.$confirm('确认删除该专家？', '提示', { type: 'warning' }).then(async () => {
        try {
          await deleteExpert(row.id)
          this.$message.success('删除成功')
          this.fetchData()
        } catch (error) {
          this.$message.error('删除失败')
        }
      })
    }
  }
}
</script>
