import request from '@/utils/request'

export function getExpertList(params) {
  return request({
    url: '/expert/list',
    method: 'get',
    params
  })
}

export function getExpertById(id) {
  return request({
    url: `/expert/${id}`,
    method: 'get'
  })
}

export function createExpert(data) {
  return request({
    url: '/expert',
    method: 'post',
    data
  })
}

export function updateExpert(id, data) {
  return request({
    url: `/expert/${id}`,
    method: 'put',
    data
  })
}

export function deleteExpert(id) {
  return request({
    url: `/expert/${id}`,
    method: 'delete'
  })
}

export function getExpertTypes() {
  return request({
    url: '/expert-type/list',
    method: 'get'
  })
}