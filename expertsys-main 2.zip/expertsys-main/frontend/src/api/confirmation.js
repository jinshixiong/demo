import request from '@/utils/request'

export function getConfirmationInfo(token) {
  return request({
    url: `/confirmation/${token}`,
    method: 'get'
  })
}

export function submitConfirmation(token, data) {
  return request({
    url: `/confirmation/${token}`,
    method: 'post',
    data
  })
}

export function resendConfirmation(recordId, expertId) {
  return request({
    url: `/confirmation/resend`,
    method: 'post',
    data: { recordId, expertId }
  })
}