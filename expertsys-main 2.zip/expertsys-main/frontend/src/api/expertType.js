import request from '@/utils/request'

export function getExpertTypeList(params) {
  return request({
    url: '/expert-type/list',
    method: 'get',
    params
  })
}

export function getExpertTypeById(id) {
  return request({
    url: `/expert-type/${id}`,
    method: 'get'
  })
}

export function createExpertType(data) {
  return request({
    url: '/expert-type',
    method: 'post',
    data
  })
}

export function updateExpertType(id, data) {
  return request({
    url: `/expert-type/${id}`,
    method: 'put',
    data
  })
}

export function deleteExpertType(id) {
  return request({
    url: `/expert-type/${id}`,
    method: 'delete'
  })
}