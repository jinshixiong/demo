import request from '@/utils/request'

export function getExtractRecordList(params) {
  return request({
    url: '/extract/record/list',
    method: 'get',
    params
  })
}

export function getExtractRecordById(id) {
  return request({
    url: `/extract/record/${id}`,
    method: 'get'
  })
}

export function createExtractTask(data) {
  return request({
    url: '/extract/task',
    method: 'post',
    data
  })
}

export function executeExtract(id) {
  return request({
    url: `/extract/execute/${id}`,
    method: 'post'
  })
}

export function getExtractResult(id) {
  return request({
    url: `/extract/result/${id}`,
    method: 'get'
  })
}

export function sendConfirmation(id, data) {
  return request({
    url: `/extract/confirmation/${id}`,
    method: 'post',
    data
  })
}

export function getExpertTypes() {
  return request({
    url: '/expert-type/list',
    method: 'get'
  })
}

export function getProjects() {
  return request({
    url: '/project/list',
    method: 'get',
    params: { page: 1, size: 1000 }
  })
}