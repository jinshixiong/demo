import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    redirect: '/expert/type'
  },
  {
    path: '/expert/type',
    name: 'ExpertType',
    component: () => import('@/views/expert/TypeList.vue')
  },
  {
    path: '/expert/list',
    name: 'ExpertList',
    component: () => import('@/views/expert/ExpertList.vue')
  },
  {
    path: '/extract',
    name: 'Extract',
    component: () => import('@/views/extract/Extract.vue')
  },
  {
    path: '/record',
    name: 'RecordList',
    component: () => import('@/views/record/RecordList.vue')
  },
  {
    path: '/confirmation/:token',
    name: 'Confirmation',
    component: () => import('@/views/confirmation/Confirm.vue')
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router