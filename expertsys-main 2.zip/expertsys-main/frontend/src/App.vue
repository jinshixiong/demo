<template>
  <div id="app">
    <el-container>
      <el-header class="app-header">
        <div class="logo">
          <h2>专家抽取管理系统</h2>
        </div>
        <el-menu
          :default-active="activeIndex"
          class="nav-menu"
          mode="horizontal"
          background-color="#545c64"
          text-color="#fff"
          active-text-color="#ffd04b"
          router
        >
          <el-menu-item index="/expert/type">专家类别管理</el-menu-item>
          <el-menu-item index="/expert/list">专家管理</el-menu-item>
          <el-menu-item index="/extract">专家抽取</el-menu-item>
          <el-menu-item index="/record">抽取记录</el-menu-item>
        </el-menu>
      </el-header>
      <el-main class="app-main">
        <router-view />
      </el-main>
      <el-footer class="app-footer">
        <p>© 2024 专家抽取管理系统</p>
      </el-footer>
    </el-container>
  </div>
</template>

<script>
export default {
  name: 'App',
  computed: {
    activeIndex() {
      return this.$route.path
    }
  }
}
</script>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: 'Helvetica Neue', Helvetica, 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', Arial, sans-serif;
}

#app {
  min-height: 100vh;
}

.app-header {
  background-color: #545c64;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 20px;
}

.logo h2 {
  color: #fff;
  margin: 0;
}

.nav-menu {
  border-bottom: none;
}

.app-main {
  background-color: #f5f7fa;
  min-height: calc(100vh - 120px);
  padding: 20px;
}

.app-footer {
  background-color: #545c64;
  color: #fff;
  text-align: center;
  line-height: 60px;
}

.app-footer p {
  margin: 0;
}
</style>