-- 评标专家抽取系统数据库脚本

-- 专家类型表
CREATE TABLE IF NOT EXISTS expert_type (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL COMMENT '类型名称',
    sort_order INT DEFAULT 0 COMMENT '排序',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) COMMENT='专家类型表';

-- 专家表
CREATE TABLE IF NOT EXISTS expert (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL COMMENT '姓名',
    id_card_encrypted VARCHAR(255) COMMENT '身份证号(加密)',
    id_card_hash VARCHAR(255) COMMENT '身份证号哈希',
    phone VARCHAR(20) COMMENT '手机号',
    remark TEXT COMMENT '备注',
    project_count INT DEFAULT 0 COMMENT '参与项目数',
    status INT DEFAULT 1 COMMENT '状态: 0-禁用, 1-启用',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) COMMENT='专家表';

-- 专家类型关联表
CREATE TABLE IF NOT EXISTS expert_type_relation (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    expert_id BIGINT NOT NULL COMMENT '专家ID',
    type_id BIGINT NOT NULL COMMENT '类型ID',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (expert_id) REFERENCES expert(id) ON DELETE CASCADE,
    FOREIGN KEY (type_id) REFERENCES expert_type(id) ON DELETE CASCADE
) COMMENT='专家类型关联表';

-- 项目表
CREATE TABLE IF NOT EXISTS project (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL COMMENT '项目名称',
    code VARCHAR(100) COMMENT '项目编号',
    opener_name VARCHAR(50) COMMENT '开标人姓名',
    opener_id_card_hash VARCHAR(255) COMMENT '开标人身份证号哈希',
    open_time DATETIME COMMENT '开标时间',
    expert_count INT DEFAULT 0 COMMENT '需要专家数',
    status INT DEFAULT 0 COMMENT '状态: 0-待抽取, 1-抽取中, 2-已完成',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) COMMENT='项目表';

-- 项目类型关联表
CREATE TABLE IF NOT EXISTS project_type_relation (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    project_id BIGINT NOT NULL COMMENT '项目ID',
    type_id BIGINT NOT NULL COMMENT '类型ID',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES project(id) ON DELETE CASCADE,
    FOREIGN KEY (type_id) REFERENCES expert_type(id) ON DELETE CASCADE
) COMMENT='项目类型关联表';

-- 抽取记录表
CREATE TABLE IF NOT EXISTS extract_record (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    project_id BIGINT NOT NULL COMMENT '项目ID',
    expert_id BIGINT NOT NULL COMMENT '专家ID',
    type_id BIGINT NOT NULL COMMENT '专家类型ID',
    meeting_type VARCHAR(50) COMMENT '会议类型',
    status INT DEFAULT 0 COMMENT '状态: 0-待确认, 1-已确认, 2-已取消',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES project(id) ON DELETE CASCADE,
    FOREIGN KEY (expert_id) REFERENCES expert(id) ON DELETE CASCADE
) COMMENT='抽取记录表';

-- 专家确认表
CREATE TABLE IF NOT EXISTS expert_confirmation (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    record_id BIGINT NOT NULL COMMENT '抽取记录ID',
    token VARCHAR(255) UNIQUE COMMENT '确认令牌',
    confirm_status INT DEFAULT 0 COMMENT '确认状态: 0-待确认, 1-已接受, 2-已拒绝',
    confirm_time DATETIME COMMENT '确认时间',
    sms_sent_time DATETIME COMMENT '短信发送时间',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (record_id) REFERENCES extract_record(id) ON DELETE CASCADE
) COMMENT='专家确认表';

-- 创建索引
CREATE INDEX idx_expert_id_card_hash ON expert(id_card_hash);
CREATE INDEX idx_expert_status ON expert(status);
CREATE INDEX idx_expert_type_relation_expert ON expert_type_relation(expert_id);
CREATE INDEX idx_expert_type_relation_type ON expert_type_relation(type_id);
CREATE INDEX idx_project_type_relation_project ON project_type_relation(project_id);
CREATE INDEX idx_project_type_relation_type ON project_type_relation(type_id);
CREATE INDEX idx_extract_record_project ON extract_record(project_id);
CREATE INDEX idx_extract_record_expert ON extract_record(expert_id);
CREATE INDEX idx_expert_confirmation_token ON expert_confirmation(token);
CREATE INDEX idx_expert_confirmation_record ON expert_confirmation(record_id);
