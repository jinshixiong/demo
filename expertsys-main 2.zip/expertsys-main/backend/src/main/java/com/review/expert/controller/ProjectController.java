package com.review.expert.controller;

import com.review.expert.dto.ProjectDTO;
import com.review.expert.entity.Project;
import com.review.expert.service.ProjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/projects")
public class ProjectController {
    
    @Autowired
    private ProjectService projectService;
    
    @GetMapping
    public ResponseEntity<List<Project>> listAll() {
        return ResponseEntity.ok(projectService.listProjects());
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<ProjectDTO> getById(@PathVariable Long id) {
        ProjectDTO dto = projectService.getProjectById(id);
        if (dto == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(dto);
    }
    
    @PostMapping
    public ResponseEntity<Boolean> save(@RequestBody ProjectDTO dto) {
        return ResponseEntity.ok(projectService.saveProject(dto));
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Boolean> update(@PathVariable Long id, @RequestBody ProjectDTO dto) {
        dto.setId(id);
        return ResponseEntity.ok(projectService.updateProject(dto));
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Boolean> delete(@PathVariable Long id) {
        return ResponseEntity.ok(projectService.deleteProject(id));
    }
}
