package com.review.expert.dto;

import lombok.Data;
import java.util.List;

@Data
public class PageResult<T> {
    
    private List<T> list;
    
    private Long total;
    
    private Long pages;
    
    private Long current;
    
    private Long size;
    
    public PageResult() {}
    
    public PageResult(List<T> list, Long total, Long current, Long size) {
        this.list = list;
        this.total = total;
        this.current = current;
        this.size = size;
        this.pages = (total + size - 1) / size;
    }
}