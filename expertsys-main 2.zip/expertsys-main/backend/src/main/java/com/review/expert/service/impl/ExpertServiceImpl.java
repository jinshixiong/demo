package com.review.expert.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.review.expert.dto.ExpertDTO;
import com.review.expert.dto.ExpertListDTO;
import com.review.expert.entity.Expert;
import com.review.expert.entity.ExpertType;
import com.review.expert.entity.ExpertTypeRelation;
import com.review.expert.mapper.ExpertMapper;
import com.review.expert.mapper.ExpertTypeMapper;
import com.review.expert.mapper.ExpertTypeRelationMapper;
import com.review.expert.service.ExpertService;
import com.review.expert.utils.IdCardCrypto;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ExpertServiceImpl extends ServiceImpl<ExpertMapper, Expert> implements ExpertService {
    
    @Autowired
    private IdCardCrypto idCardCrypto;
    
    @Autowired
    private ExpertTypeRelationMapper typeRelationMapper;
    
    @Autowired
    private ExpertTypeMapper expertTypeMapper;
    
    @Override
    public List<ExpertListDTO> listExperts() {
        return list().stream().map(this::convertToListDTO).collect(Collectors.toList());
    }
    
    @Override
    public ExpertDTO getExpertById(Long id) {
        Expert expert = getById(id);
        if (expert == null) {
            return null;
        }
        ExpertDTO dto = new ExpertDTO();
        BeanUtils.copyProperties(expert, dto);
        dto.setIdCard(idCardCrypto.decrypt(expert.getIdCardEncrypted()));
        
        List<Long> typeIds = typeRelationMapper.selectList(
            new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<ExpertTypeRelation>()
                .eq(ExpertTypeRelation::getExpertId, id)
        ).stream().map(ExpertTypeRelation::getTypeId).collect(Collectors.toList());
        dto.setTypeIds(typeIds);
        
        return dto;
    }
    
    @Override
    @Transactional
    public boolean saveExpert(ExpertDTO dto) {
        Expert expert = new Expert();
        BeanUtils.copyProperties(dto, expert);
        expert.setIdCardEncrypted(idCardCrypto.encrypt(dto.getIdCard()));
        expert.setIdCardHash(idCardCrypto.hash(dto.getIdCard()));
        expert.setProjectCount(0);
        expert.setStatus(1);
        
        boolean success = save(expert);
        
        if (success && dto.getTypeIds() != null) {
            for (Long typeId : dto.getTypeIds()) {
                ExpertTypeRelation relation = new ExpertTypeRelation();
                relation.setExpertId(expert.getId());
                relation.setTypeId(typeId);
                typeRelationMapper.insert(relation);
            }
        }
        
        return success;
    }
    
    @Override
    @Transactional
    public boolean updateExpert(ExpertDTO dto) {
        Expert expert = new Expert();
        BeanUtils.copyProperties(dto, expert);
        if (dto.getIdCard() != null && !dto.getIdCard().isEmpty()) {
            expert.setIdCardEncrypted(idCardCrypto.encrypt(dto.getIdCard()));
            expert.setIdCardHash(idCardCrypto.hash(dto.getIdCard()));
        }
        
        boolean success = updateById(expert);
        
        if (success && dto.getTypeIds() != null) {
            typeRelationMapper.delete(
                new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<ExpertTypeRelation>()
                    .eq(ExpertTypeRelation::getExpertId, dto.getId())
            );
            for (Long typeId : dto.getTypeIds()) {
                ExpertTypeRelation relation = new ExpertTypeRelation();
                relation.setExpertId(dto.getId());
                relation.setTypeId(typeId);
                typeRelationMapper.insert(relation);
            }
        }
        
        return success;
    }
    
    @Override
    @Transactional
    public boolean deleteExpert(Long id) {
        typeRelationMapper.delete(
            new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<ExpertTypeRelation>()
                .eq(ExpertTypeRelation::getExpertId, id)
        );
        return removeById(id);
    }
    
    @Override
    public List<Expert> findAvailableExperts(Long typeId, String excludeHash) {
        return baseMapper.findAvailableExpertsByType(typeId, excludeHash);
    }
    
    @Override
    public String getDecryptedIdCard(Long expertId) {
        Expert expert = getById(expertId);
        if (expert == null) {
            return null;
        }
        return idCardCrypto.decrypt(expert.getIdCardEncrypted());
    }
    
    private ExpertListDTO convertToListDTO(Expert expert) {
        ExpertListDTO dto = new ExpertListDTO();
        BeanUtils.copyProperties(expert, dto);
        
        String decryptedIdCard = idCardCrypto.decrypt(expert.getIdCardEncrypted());
        dto.setIdCardMasked(idCardCrypto.mask(decryptedIdCard));
        
        List<String> typeNames = typeRelationMapper.selectList(
            new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<ExpertTypeRelation>()
                .eq(ExpertTypeRelation::getExpertId, expert.getId())
        ).stream().map(relation -> {
            ExpertType type = expertTypeMapper.selectById(relation.getTypeId());
            return type != null ? type.getName() : "";
        }).collect(Collectors.toList());
        dto.setTypeNames(typeNames);
        
        return dto;
    }
}