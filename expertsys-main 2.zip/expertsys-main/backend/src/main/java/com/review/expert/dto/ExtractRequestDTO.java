package com.review.expert.dto;

import lombok.Data;
import java.util.List;

@Data
public class ExtractRequestDTO {
    
    private Long projectId;
    
    private List<ExpertTypeRequirement> requirements;
    
    @Data
    public static class ExpertTypeRequirement {
        private Long typeId;
        private Integer count;
        private String meetingType;
    }
}