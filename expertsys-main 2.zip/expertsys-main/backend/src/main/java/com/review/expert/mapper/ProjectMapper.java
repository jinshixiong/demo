package com.review.expert.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.review.expert.entity.Project;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ProjectMapper extends BaseMapper<Project> {
}