package com.review.expert.dto;

import lombok.Data;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class ProjectDTO {
    
    private Long id;
    
    private String name;
    
    private String code;
    
    private String openerName;
    
    private String openerIdCard;
    
    private LocalDateTime openTime;
    
    private Integer expertCount;
    
    private Integer status;
    
    private List<Long> typeIds;
}