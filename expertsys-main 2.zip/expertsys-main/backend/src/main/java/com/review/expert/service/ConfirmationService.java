package com.review.expert.service;

import com.review.expert.dto.ConfirmationDTO;
import com.review.expert.entity.ExpertConfirmation;

public interface ConfirmationService {
    
    ExpertConfirmation generateConfirmation(Long recordId);
    
    boolean sendConfirmationSms(Long confirmationId);
    
    boolean confirmByToken(String token, boolean accepted);
    
    ConfirmationDTO getConfirmationByToken(String token);
    
    boolean autoReExtractIfDeclined(String token);
}
