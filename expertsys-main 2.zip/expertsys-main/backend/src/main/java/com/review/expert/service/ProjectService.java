package com.review.expert.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.review.expert.dto.ProjectDTO;
import com.review.expert.entity.Project;

import java.util.List;

public interface ProjectService extends IService<Project> {
    
    List<Project> listProjects();
    
    ProjectDTO getProjectById(Long id);
    
    boolean saveProject(ProjectDTO dto);
    
    boolean updateProject(ProjectDTO dto);
    
    boolean deleteProject(Long id);
}