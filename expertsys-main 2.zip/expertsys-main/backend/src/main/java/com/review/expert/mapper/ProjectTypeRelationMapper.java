package com.review.expert.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.review.expert.entity.ProjectTypeRelation;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface ProjectTypeRelationMapper extends BaseMapper<ProjectTypeRelation> {
    
    @Select("SELECT * FROM project_type_relation WHERE project_id = #{projectId}")
    List<ProjectTypeRelation> findByProjectId(@Param("projectId") Long projectId);
    
    @Select("SELECT type_id FROM project_type_relation WHERE project_id = #{projectId}")
    List<Long> findTypeIdsByProjectId(@Param("projectId") Long projectId);
}