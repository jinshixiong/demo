package com.review.expert.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.review.expert.dto.ExtractRequestDTO;
import com.review.expert.dto.ExtractResultDTO;
import com.review.expert.entity.Expert;
import com.review.expert.entity.ExpertType;
import com.review.expert.entity.ExtractRecord;
import com.review.expert.entity.Project;
import com.review.expert.mapper.ExpertMapper;
import com.review.expert.mapper.ExpertTypeMapper;
import com.review.expert.mapper.ExtractRecordMapper;
import com.review.expert.mapper.ProjectMapper;
import com.review.expert.service.ExtractService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ExtractServiceImpl implements ExtractService {
    
    @Autowired
    private ExpertMapper expertMapper;
    
    @Autowired
    private ProjectMapper projectMapper;
    
    @Autowired
    private ExtractRecordMapper extractRecordMapper;
    
    @Autowired
    private ExpertTypeMapper expertTypeMapper;
    
    @Override
    @Transactional
    public List<ExtractResultDTO> extractExperts(ExtractRequestDTO request) {
        Project project = projectMapper.selectById(request.getProjectId());
        if (project == null) {
            throw new RuntimeException("项目不存在");
        }
        
        String excludeHash = project.getOpenerIdCardHash();
        List<ExtractResultDTO> results = new ArrayList<>();
        
        for (ExtractRequestDTO.ExpertTypeRequirement req : request.getRequirements()) {
            List<Expert> availableExperts = expertMapper.findAvailableExpertsByType(req.getTypeId(), excludeHash);
            
            List<Long> extractedExpertIds = extractRecordMapper.findByProjectId(request.getProjectId())
                    .stream().map(ExtractRecord::getExpertId).collect(Collectors.toList());
            availableExperts = availableExperts.stream()
                    .filter(e -> !extractedExpertIds.contains(e.getId()))
                    .collect(Collectors.toList());
            
            if (availableExperts.size() < req.getCount()) {
                throw new RuntimeException("专业类型可用专家数量不足");
            }
            
            Collections.shuffle(availableExperts);
            List<Expert> selectedExperts = availableExperts.subList(0, req.getCount());
            
            ExpertType type = expertTypeMapper.selectById(req.getTypeId());
            
            for (Expert expert : selectedExperts) {
                ExtractRecord record = new ExtractRecord();
                record.setProjectId(request.getProjectId());
                record.setExpertId(expert.getId());
                record.setTypeId(req.getTypeId());
                record.setMeetingType(req.getMeetingType());
                record.setStatus(0);
                extractRecordMapper.insert(record);
                
                ExtractResultDTO dto = new ExtractResultDTO();
                dto.setRecordId(record.getId());
                dto.setExpertId(expert.getId());
                dto.setExpertName(expert.getName());
                dto.setExpertPhone(expert.getPhone());
                dto.setTypeName(type != null ? type.getName() : "");
                dto.setMeetingType(req.getMeetingType());
                dto.setStatus(0);
                results.add(dto);
            }
        }
        
        return results;
    }
    
    @Override
    public List<ExtractResultDTO> getExtractResults(Long projectId) {
        List<ExtractRecord> records = extractRecordMapper.findByProjectId(projectId);
        return records.stream().map(this::convertToDTO).collect(Collectors.toList());
    }
    
    @Override
    @Transactional
    public boolean cancelExtract(Long recordId) {
        ExtractRecord record = extractRecordMapper.selectById(recordId);
        if (record == null) {
            return false;
        }
        record.setStatus(2);
        return extractRecordMapper.updateById(record) > 0;
    }
    
    @Override
    @Transactional
    public boolean confirmExtract(Long recordId) {
        ExtractRecord record = extractRecordMapper.selectById(recordId);
        if (record == null) {
            return false;
        }
        record.setStatus(1);
        return extractRecordMapper.updateById(record) > 0;
    }
    
    @Override
    @Transactional
    public boolean reExtract(Long recordId, ExtractRequestDTO request) {
        cancelExtract(recordId);
        List<ExtractResultDTO> results = extractExperts(request);
        return !results.isEmpty();
    }
    
    private ExtractResultDTO convertToDTO(ExtractRecord record) {
        ExtractResultDTO dto = new ExtractResultDTO();
        BeanUtils.copyProperties(record, dto);
        dto.setRecordId(record.getId());
        
        Expert expert = expertMapper.selectById(record.getExpertId());
        if (expert != null) {
            dto.setExpertName(expert.getName());
            dto.setExpertPhone(expert.getPhone());
        }
        
        ExpertType type = expertTypeMapper.selectById(record.getTypeId());
        if (type != null) {
            dto.setTypeName(type.getName());
        }
        
        return dto;
    }
}
