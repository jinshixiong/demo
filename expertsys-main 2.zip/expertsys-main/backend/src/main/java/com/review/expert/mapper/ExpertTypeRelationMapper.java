package com.review.expert.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.review.expert.entity.ExpertTypeRelation;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ExpertTypeRelationMapper extends BaseMapper<ExpertTypeRelation> {
}