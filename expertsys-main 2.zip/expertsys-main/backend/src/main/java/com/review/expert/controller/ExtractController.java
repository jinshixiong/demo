package com.review.expert.controller;

import com.review.expert.dto.ExtractRequestDTO;
import com.review.expert.dto.ExtractResultDTO;
import com.review.expert.service.ExtractService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/extracts")
public class ExtractController {
    
    @Autowired
    private ExtractService extractService;
    
    @PostMapping("/extract")
    public ResponseEntity<List<ExtractResultDTO>> extract(@RequestBody ExtractRequestDTO request) {
        return ResponseEntity.ok(extractService.extractExperts(request));
    }
    
    @GetMapping("/project/{projectId}")
    public ResponseEntity<List<ExtractResultDTO>> getByProject(@PathVariable Long projectId) {
        return ResponseEntity.ok(extractService.getExtractResults(projectId));
    }
    
    @PutMapping("/{recordId}/cancel")
    public ResponseEntity<Boolean> cancel(@PathVariable Long recordId) {
        return ResponseEntity.ok(extractService.cancelExtract(recordId));
    }
    
    @PutMapping("/{recordId}/confirm")
    public ResponseEntity<Boolean> confirm(@PathVariable Long recordId) {
        return ResponseEntity.ok(extractService.confirmExtract(recordId));
    }
    
    @PostMapping("/{recordId}/re-extract")
    public ResponseEntity<Boolean> reExtract(@PathVariable Long recordId, @RequestBody ExtractRequestDTO request) {
        return ResponseEntity.ok(extractService.reExtract(recordId, request));
    }
}
