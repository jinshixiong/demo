package com.review.expert.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.review.expert.dto.ExpertTypeDTO;
import com.review.expert.entity.ExpertType;
import com.review.expert.mapper.ExpertTypeMapper;
import com.review.expert.service.ExpertTypeService;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ExpertTypeServiceImpl extends ServiceImpl<ExpertTypeMapper, ExpertType> implements ExpertTypeService {
    
    @Override
    public List<ExpertTypeDTO> listAll() {
        return list().stream().map(this::convertToDTO).collect(Collectors.toList());
    }
    
    @Override
    public ExpertTypeDTO getTypeById(Long id) {
        ExpertType type = getById(id);
        return type != null ? convertToDTO(type) : null;
    }
    
    @Override
    public boolean saveType(ExpertTypeDTO dto) {
        ExpertType type = new ExpertType();
        BeanUtils.copyProperties(dto, type);
        return save(type);
    }
    
    @Override
    public boolean updateType(ExpertTypeDTO dto) {
        ExpertType type = new ExpertType();
        BeanUtils.copyProperties(dto, type);
        return updateById(type);
    }
    
    @Override
    public boolean deleteType(Long id) {
        return removeById(id);
    }
    
    private ExpertTypeDTO convertToDTO(ExpertType type) {
        ExpertTypeDTO dto = new ExpertTypeDTO();
        BeanUtils.copyProperties(type, dto);
        return dto;
    }
}