package com.review.expert;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.review.expert.mapper")
public class ExpertExtractApplication {
    public static void main(String[] args) {
        SpringApplication.run(ExpertExtractApplication.class, args);
    }
}