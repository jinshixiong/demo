package com.review.expert.controller;

import com.review.expert.dto.ExpertTypeDTO;
import com.review.expert.service.ExpertTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/expert-types")
public class ExpertTypeController {
    
    @Autowired
    private ExpertTypeService expertTypeService;
    
    @GetMapping
    public ResponseEntity<List<ExpertTypeDTO>> listAll() {
        return ResponseEntity.ok(expertTypeService.listAll());
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<ExpertTypeDTO> getById(@PathVariable Long id) {
        ExpertTypeDTO dto = expertTypeService.getTypeById(id);
        if (dto == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(dto);
    }
    
    @PostMapping
    public ResponseEntity<Boolean> save(@RequestBody ExpertTypeDTO dto) {
        return ResponseEntity.ok(expertTypeService.saveType(dto));
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Boolean> update(@PathVariable Long id, @RequestBody ExpertTypeDTO dto) {
        dto.setId(id);
        return ResponseEntity.ok(expertTypeService.updateType(dto));
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Boolean> delete(@PathVariable Long id) {
        return ResponseEntity.ok(expertTypeService.deleteType(id));
    }
}
