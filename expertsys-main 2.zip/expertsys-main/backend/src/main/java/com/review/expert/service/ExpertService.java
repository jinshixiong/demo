package com.review.expert.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.review.expert.dto.ExpertDTO;
import com.review.expert.dto.ExpertListDTO;
import com.review.expert.entity.Expert;

import java.util.List;

public interface ExpertService extends IService<Expert> {
    
    List<ExpertListDTO> listExperts();
    
    ExpertDTO getExpertById(Long id);
    
    boolean saveExpert(ExpertDTO dto);
    
    boolean updateExpert(ExpertDTO dto);
    
    boolean deleteExpert(Long id);
    
    List<Expert> findAvailableExperts(Long typeId, String excludeHash);
    
    String getDecryptedIdCard(Long expertId);
}