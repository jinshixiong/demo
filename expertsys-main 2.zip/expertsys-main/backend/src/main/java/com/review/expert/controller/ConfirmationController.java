package com.review.expert.controller;

import com.review.expert.dto.ConfirmationDTO;
import com.review.expert.service.ConfirmationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/confirmations")
public class ConfirmationController {
    
    @Autowired
    private ConfirmationService confirmationService;
    
    @PostMapping("/generate/{recordId}")
    public ResponseEntity<String> generate(@PathVariable Long recordId) {
        return ResponseEntity.ok(confirmationService.generateConfirmation(recordId).getToken());
    }
    
    @GetMapping("/token/{token}")
    public ResponseEntity<ConfirmationDTO> getByToken(@PathVariable String token) {
        ConfirmationDTO dto = confirmationService.getConfirmationByToken(token);
        if (dto == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(dto);
    }
    
    @PostMapping("/confirm/{token}")
    public ResponseEntity<Boolean> confirm(@PathVariable String token, @RequestParam boolean accepted) {
        return ResponseEntity.ok(confirmationService.confirmByToken(token, accepted));
    }
    
    @PostMapping("/{confirmationId}/send-sms")
    public ResponseEntity<Boolean> sendSms(@PathVariable Long confirmationId) {
        return ResponseEntity.ok(confirmationService.sendConfirmationSms(confirmationId));
    }
}
