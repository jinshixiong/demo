package com.review.expert.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.review.expert.entity.Expert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface ExpertMapper extends BaseMapper<Expert> {
    
    @Select("SELECT e.* FROM expert e " +
            "INNER JOIN expert_type_relation etr ON e.id = etr.expert_id " +
            "WHERE etr.type_id = #{typeId} AND e.status = 1 " +
            "AND e.id_card_hash != #{excludeHash}")
    List<Expert> findAvailableExpertsByType(@Param("typeId") Long typeId, @Param("excludeHash") String excludeHash);
}