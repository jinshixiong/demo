package com.review.expert.dto;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class ConfirmationDTO {
    
    private Long id;
    
    private Long recordId;
    
    private String token;
    
    private Integer confirmStatus;
    
    private LocalDateTime confirmTime;
    
    private LocalDateTime smsSentTime;
    
    private String expertName;
    
    private String projectName;
}