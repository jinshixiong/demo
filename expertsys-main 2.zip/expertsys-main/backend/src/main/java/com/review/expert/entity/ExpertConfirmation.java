package com.review.expert.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@TableName("expert_confirmation")
public class ExpertConfirmation {
    
    @TableId(type = IdType.AUTO)
    private Long id;
    
    private Long recordId;
    
    private String token;
    
    private Integer confirmStatus;
    
    private LocalDateTime confirmTime;
    
    private LocalDateTime smsSentTime;
    
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createdAt;
}