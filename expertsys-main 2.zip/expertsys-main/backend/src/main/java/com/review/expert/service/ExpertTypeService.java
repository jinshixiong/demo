package com.review.expert.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.review.expert.dto.ExpertTypeDTO;
import com.review.expert.entity.ExpertType;

import java.util.List;

public interface ExpertTypeService extends IService<ExpertType> {
    
    List<ExpertTypeDTO> listAll();
    
    ExpertTypeDTO getTypeById(Long id);
    
    boolean saveType(ExpertTypeDTO dto);
    
    boolean updateType(ExpertTypeDTO dto);
    
    boolean deleteType(Long id);
}