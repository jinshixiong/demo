package com.review.expert.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.review.expert.entity.ExpertType;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ExpertTypeMapper extends BaseMapper<ExpertType> {
}