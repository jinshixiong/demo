package com.review.expert.controller;

import com.review.expert.dto.ExpertDTO;
import com.review.expert.dto.ExpertListDTO;
import com.review.expert.service.ExpertService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/experts")
public class ExpertController {
    
    @Autowired
    private ExpertService expertService;
    
    @GetMapping
    public ResponseEntity<List<ExpertListDTO>> listAll() {
        return ResponseEntity.ok(expertService.listExperts());
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<ExpertDTO> getById(@PathVariable Long id) {
        ExpertDTO dto = expertService.getExpertById(id);
        if (dto == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(dto);
    }
    
    @PostMapping
    public ResponseEntity<Boolean> save(@RequestBody ExpertDTO dto) {
        return ResponseEntity.ok(expertService.saveExpert(dto));
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Boolean> update(@PathVariable Long id, @RequestBody ExpertDTO dto) {
        dto.setId(id);
        return ResponseEntity.ok(expertService.updateExpert(dto));
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Boolean> delete(@PathVariable Long id) {
        return ResponseEntity.ok(expertService.deleteExpert(id));
    }
}
