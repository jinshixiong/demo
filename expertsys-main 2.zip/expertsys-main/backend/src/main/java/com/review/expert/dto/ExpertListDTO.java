package com.review.expert.dto;

import lombok.Data;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class ExpertListDTO {
    
    private Long id;
    
    private String name;
    
    private String phone;
    
    private String idCardMasked;
    
    private Integer projectCount;
    
    private Integer status;
    
    private List<String> typeNames;
    
    private LocalDateTime createdAt;
}