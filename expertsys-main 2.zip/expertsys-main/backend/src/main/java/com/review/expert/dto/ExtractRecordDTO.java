package com.review.expert.dto;

import lombok.Data;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class ExtractRecordDTO {
    
    private Long id;
    
    private Long projectId;
    
    private String projectName;
    
    private String projectCode;
    
    private LocalDateTime extractTime;
    
    private List<ExpertDetail> experts;
    
    @Data
    public static class ExpertDetail {
        private Long expertId;
        private String expertName;
        private String typeName;
        private String meetingType;
        private Integer confirmStatus;
        private String confirmStatusText;
    }
}