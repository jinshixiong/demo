package com.review.expert.dto;

import lombok.Data;

@Data
public class ExpertTypeDTO {
    
    private Long id;
    
    private String name;
    
    private Integer sortOrder;
}