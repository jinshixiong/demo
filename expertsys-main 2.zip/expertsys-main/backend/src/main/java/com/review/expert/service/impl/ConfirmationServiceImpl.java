package com.review.expert.service.impl;

import com.review.expert.dto.ConfirmationDTO;
import com.review.expert.dto.ExtractRequestDTO;
import com.review.expert.entity.ExpertConfirmation;
import com.review.expert.entity.ExtractRecord;
import com.review.expert.entity.Project;
import com.review.expert.mapper.ExpertConfirmationMapper;
import com.review.expert.mapper.ExtractRecordMapper;
import com.review.expert.mapper.ProjectMapper;
import com.review.expert.service.ConfirmationService;
import com.review.expert.service.ExtractService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
public class ConfirmationServiceImpl implements ConfirmationService {
    
    @Autowired
    private ExpertConfirmationMapper confirmationMapper;
    
    @Autowired
    private ExtractRecordMapper extractRecordMapper;
    
    @Autowired
    private ProjectMapper projectMapper;
    
    @Autowired
    private ExtractService extractService;
    
    @Override
    @Transactional
    public ExpertConfirmation generateConfirmation(Long recordId) {
        ExtractRecord record = extractRecordMapper.selectById(recordId);
        if (record == null) {
            throw new RuntimeException("抽取记录不存在");
        }
        
        ExpertConfirmation existing = confirmationMapper.findByRecordId(recordId);
        if (existing != null) {
            return existing;
        }
        
        ExpertConfirmation confirmation = new ExpertConfirmation();
        confirmation.setRecordId(recordId);
        confirmation.setToken(UUID.randomUUID().toString().replace("-", ""));
        confirmation.setConfirmStatus(0);
        confirmationMapper.insert(confirmation);
        
        return confirmation;
    }
    
    @Override
    public boolean sendConfirmationSms(Long confirmationId) {
        ExpertConfirmation confirmation = confirmationMapper.selectById(confirmationId);
        if (confirmation == null) {
            return false;
        }
        
        // TODO: 集成短信服务发送短信
        confirmation.setSmsSentTime(LocalDateTime.now());
        confirmationMapper.updateById(confirmation);
        
        return true;
    }
    
    @Override
    @Transactional
    public boolean confirmByToken(String token, boolean accepted) {
        ExpertConfirmation confirmation = confirmationMapper.findByToken(token);
        if (confirmation == null) {
            throw new RuntimeException("无效的确认链接");
        }
        
        if (confirmation.getConfirmStatus() != 0) {
            throw new RuntimeException("该记录已处理");
        }
        
        confirmation.setConfirmStatus(accepted ? 1 : 2);
        confirmation.setConfirmTime(LocalDateTime.now());
        confirmationMapper.updateById(confirmation);
        
        // 更新抽取记录状态
        ExtractRecord record = extractRecordMapper.selectById(confirmation.getRecordId());
        if (record != null) {
            if (accepted) {
                record.setStatus(1); // 已确认
            } else {
                record.setStatus(2); // 已拒绝
            }
            extractRecordMapper.updateById(record);
        }
        
        // 如果拒绝，自动重新抽取
        if (!accepted) {
            autoReExtractIfDeclined(token);
        }
        
        return true;
    }
    
    @Override
    public ConfirmationDTO getConfirmationByToken(String token) {
        ExpertConfirmation confirmation = confirmationMapper.findByToken(token);
        if (confirmation == null) {
            return null;
        }
        
        ConfirmationDTO dto = new ConfirmationDTO();
        BeanUtils.copyProperties(confirmation, dto);
        
        ExtractRecord record = extractRecordMapper.selectById(confirmation.getRecordId());
        if (record != null) {
            dto.setExpertName(record.getExpertId().toString()); // 简化处理，实际应从Expert表获取
            
            Project project = projectMapper.selectById(record.getProjectId());
            if (project != null) {
                dto.setProjectName(project.getName());
            }
        }
        
        return dto;
    }
    
    @Override
    @Transactional
    public boolean autoReExtractIfDeclined(String token) {
        ExpertConfirmation confirmation = confirmationMapper.findByToken(token);
        if (confirmation == null || confirmation.getConfirmStatus() != 2) {
            return false;
        }
        
        ExtractRecord record = extractRecordMapper.selectById(confirmation.getRecordId());
        if (record == null) {
            return false;
        }
        
        // 构建重新抽取请求
        ExtractRequestDTO request = new ExtractRequestDTO();
        request.setProjectId(record.getProjectId());
        
        ExtractRequestDTO.ExpertTypeRequirement req = new ExtractRequestDTO.ExpertTypeRequirement();
        req.setTypeId(record.getTypeId());
        req.setCount(1);
        req.setMeetingType(record.getMeetingType());
        
        List<ExtractRequestDTO.ExpertTypeRequirement> requirements = new ArrayList<>();
        requirements.add(req);
        request.setRequirements(requirements);
        
        // 重新抽取
        extractService.reExtract(record.getId(), request);
        
        return true;
    }
}
