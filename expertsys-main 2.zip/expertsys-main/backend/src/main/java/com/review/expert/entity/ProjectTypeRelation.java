package com.review.expert.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@TableName("project_type_relation")
public class ProjectTypeRelation {
    
    @TableId(type = IdType.AUTO)
    private Long id;
    
    private Long projectId;
    
    private Long typeId;
    
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createdAt;
}