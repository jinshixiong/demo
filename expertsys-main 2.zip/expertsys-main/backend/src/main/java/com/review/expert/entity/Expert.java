package com.review.expert.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@TableName("expert")
public class Expert {
    
    @TableId(type = IdType.AUTO)
    private Long id;
    
    private String name;
    
    private String idCardEncrypted;
    
    private String idCardHash;
    
    private String phone;
    
    private String remark;
    
    private Integer projectCount;
    
    private Integer status;
    
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createdAt;
    
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updatedAt;
}