package com.review.expert.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.review.expert.dto.ProjectDTO;
import com.review.expert.entity.Project;
import com.review.expert.entity.ProjectTypeRelation;
import com.review.expert.mapper.ProjectMapper;
import com.review.expert.mapper.ProjectTypeRelationMapper;
import com.review.expert.service.ProjectService;
import com.review.expert.utils.IdCardCrypto;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProjectServiceImpl extends ServiceImpl<ProjectMapper, Project> implements ProjectService {
    
    @Autowired
    private IdCardCrypto idCardCrypto;
    
    @Autowired
    private ProjectTypeRelationMapper typeRelationMapper;
    
    @Override
    public List<Project> listProjects() {
        return list();
    }
    
    @Override
    public ProjectDTO getProjectById(Long id) {
        Project project = getById(id);
        if (project == null) {
            return null;
        }
        ProjectDTO dto = new ProjectDTO();
        BeanUtils.copyProperties(project, dto);
        dto.setOpenerIdCard(idCardCrypto.decrypt(project.getOpenerIdCardHash()));
        
        List<Long> typeIds = typeRelationMapper.findTypeIdsByProjectId(id);
        dto.setTypeIds(typeIds);
        
        return dto;
    }
    
    @Override
    @Transactional
    public boolean saveProject(ProjectDTO dto) {
        Project project = new Project();
        BeanUtils.copyProperties(dto, project);
        project.setOpenerIdCardHash(idCardCrypto.hash(dto.getOpenerIdCard()));
        project.setStatus(0);
        
        boolean success = save(project);
        
        if (success && dto.getTypeIds() != null) {
            for (Long typeId : dto.getTypeIds()) {
                ProjectTypeRelation relation = new ProjectTypeRelation();
                relation.setProjectId(project.getId());
                relation.setTypeId(typeId);
                typeRelationMapper.insert(relation);
            }
        }
        
        return success;
    }
    
    @Override
    @Transactional
    public boolean updateProject(ProjectDTO dto) {
        Project project = new Project();
        BeanUtils.copyProperties(dto, project);
        if (dto.getOpenerIdCard() != null && !dto.getOpenerIdCard().isEmpty()) {
            project.setOpenerIdCardHash(idCardCrypto.hash(dto.getOpenerIdCard()));
        }
        
        boolean success = updateById(project);
        
        if (success && dto.getTypeIds() != null) {
            typeRelationMapper.delete(
                new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<ProjectTypeRelation>()
                    .eq(ProjectTypeRelation::getProjectId, dto.getId())
            );
            for (Long typeId : dto.getTypeIds()) {
                ProjectTypeRelation relation = new ProjectTypeRelation();
                relation.setProjectId(dto.getId());
                relation.setTypeId(typeId);
                typeRelationMapper.insert(relation);
            }
        }
        
        return success;
    }
    
    @Override
    @Transactional
    public boolean deleteProject(Long id) {
        typeRelationMapper.delete(
            new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<ProjectTypeRelation>()
                .eq(ProjectTypeRelation::getProjectId, id)
        );
        return removeById(id);
    }
}
