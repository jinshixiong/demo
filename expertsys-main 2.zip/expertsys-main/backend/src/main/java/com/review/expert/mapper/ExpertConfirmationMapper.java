package com.review.expert.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.review.expert.entity.ExpertConfirmation;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

@Mapper
public interface ExpertConfirmationMapper extends BaseMapper<ExpertConfirmation> {
    
    @Select("SELECT * FROM expert_confirmation WHERE token = #{token}")
    ExpertConfirmation findByToken(@Param("token") String token);
    
    @Select("SELECT * FROM expert_confirmation WHERE record_id = #{recordId}")
    ExpertConfirmation findByRecordId(@Param("recordId") Long recordId);
    
    @Update("UPDATE expert_confirmation SET confirm_status = #{status}, confirm_time = NOW() WHERE token = #{token}")
    int updateStatusByToken(@Param("token") String token, @Param("status") Integer status);
}