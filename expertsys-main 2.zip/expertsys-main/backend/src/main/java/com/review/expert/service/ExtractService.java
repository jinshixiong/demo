package com.review.expert.service;

import com.review.expert.dto.ExtractRequestDTO;
import com.review.expert.dto.ExtractResultDTO;
import com.review.expert.entity.ExtractRecord;

import java.util.List;

public interface ExtractService {
    
    List<ExtractResultDTO> extractExperts(ExtractRequestDTO request);
    
    List<ExtractResultDTO> getExtractResults(Long projectId);
    
    boolean cancelExtract(Long recordId);
    
    boolean confirmExtract(Long recordId);
    
    boolean reExtract(Long recordId, ExtractRequestDTO request);
}
