package com.review.expert.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@TableName("expert_type_relation")
public class ExpertTypeRelation {
    
    @TableId(type = IdType.AUTO)
    private Long id;
    
    private Long expertId;
    
    private Long typeId;
    
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createdAt;
}