package com.review.expert.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.review.expert.entity.ExtractRecord;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface ExtractRecordMapper extends BaseMapper<ExtractRecord> {
    
    @Select("SELECT * FROM extract_record WHERE project_id = #{projectId} ORDER BY created_at")
    List<ExtractRecord> findByProjectId(@Param("projectId") Long projectId);
    
    @Select("SELECT * FROM extract_record WHERE project_id = #{projectId} AND status = 1")
    List<ExtractRecord> findConfirmedByProjectId(@Param("projectId") Long projectId);
    
    @Select("SELECT COUNT(*) FROM extract_record WHERE project_id = #{projectId} AND expert_id = #{expertId}")
    int countByProjectAndExpert(@Param("projectId") Long projectId, @Param("expertId") Long expertId);
}