package com.review.expert.dto;

import lombok.Data;
import java.util.List;

@Data
public class ExpertDTO {
    
    private Long id;
    
    private String name;
    
    private String idCard;
    
    private String phone;
    
    private String remark;
    
    private Integer status;
    
    private List<Long> typeIds;
}