package com.review.expert.dto;

import lombok.Data;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class ExtractResultDTO {
    
    private Long recordId;
    
    private Long expertId;
    
    private String expertName;
    
    private String expertPhone;
    
    private String typeName;
    
    private String meetingType;
    
    private Integer status;
    
    private LocalDateTime createdAt;
    
    @Data
    public static class ExpertInfo {
        private Long expertId;
        private String name;
        private String phone;
        private List<String> typeNames;
    }
}